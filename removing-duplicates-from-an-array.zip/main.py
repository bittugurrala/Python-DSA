def Duplicates(array):
    left = 1
    for right in range (1, len(array)):
        if array[right] != array[right-1]:
            #[1,1,2,2,2,3]
            array[left] = array[right]
            left = left +1
            
    return array
    #return [:left]   #this line prints only that part of the list which is not repeating
        
array = [1,1,2,2,2,3]
print(Duplicates(array))


"""
Here is a detailed explanation of how the function works:
the function is for sorted arrays
but for unordered list use sort method frist to sort the array. and proceed

Initialization:

The function initializes a pointer left to 1. 
This pointer will track the position where the next unique element should be placed.
The right pointer iterates over the array from the second element to the end.

Iterating through the array:

The right pointer starts at the second element (index 1) and moves to the end of the array.
For each element, the function checks if the current element (array[right]) is different from the previous element (array[right-1]).

Placing unique elements:

If the current element is different from the previous element, it means it's a unique element (not a duplicate).
The function places this unique element at the position indicated by the left pointer (array[left] = array[right]).
The left pointer is then incremented to point to the next position for a potential unique element.
Returning the modified array:

After iterating through the array, the function returns the modified array. 
Note that the portion of the array beyond the left pointer may still contain duplicates, 
but the initial part of the array up to left contains unique elements.
"""