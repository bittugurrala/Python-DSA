def isAnagram(s, t):
        if len(s) != len(t):
            return False

        S_dict = {}
        T_dict = {}
        
        #Building Hashmaps
        for i in range(len(s)):
            S_dict[s[i]] = 1 + S_dict.get(s[i], 0)
            T_dict[t[i]] = 1 + T_dict.get(t[i], 0)
        #checking the value of each key
        for char in S_dict:
            if S_dict[char] != T_dict.get(char, 0):
                return False
        return True
        
s = "anagram"
t = "nagaram"
print(isAnagram(s,t))


"""

-> Length Check:
If the lengths of s and t are not equal, return False immediately because they cannot be anagrams.

-> Initialize Dictionaries:
Initialize two dictionaries S_dict and T_dict to count occurrences of each character in s and t, respectively.

-> Build Dictionaries:
Iterate through each character in s and t.
Update the count of each character in S_dict and T_dict.

-> Compare Dictionaries:
Iterate through the keys in S_dict (or T_dict since both should have the same keys).
Compare the counts of each character:
If the count in S_dict does not match the count in T_dict, return False.

-> Return True:
If all characters have matching counts, return True indicating that s and t are anagrams.

"""