def Duplicates(array):
    array.sort()
    for i in range(len(array)):
        if array[i] != array[i-1]:
            continue
        else:
            return "Contains Duplicates"
    return "No Duplicates found"
    

array = [1,1,13,3,4,4,4,3,4,]
print(Duplicates(array))



"""
can be solved in three ways 

Way one BruteForce 
Run two for loops and compare eacn element of the array 
Time complexity = O(n^2)
Space complexity= Constant

Way two is ** Sort and compare current element and previous element**
Sort the given array and run a for loop to check current index element and previous index element
Time complexity is O(n logn)
space complexity is Constant

Way three is** creating a HashSet to store the elements **
create a hashset to store the one time repeated elements 
complexity is Linear
Space is Linear


choosing second or Third way is good.
"""