"""def duplicate(array):
    array.sort()
    left = 1
    for right in range (1,len(array)):
        if array[right] != array[right-1]:
            array[left] = array[right]
            left = left + 1
    return array[:left]

array = [2,2,4,3,3,5,8,8,7]
print(duplicate(array))


                                OR

"""

def duplicate (array):
    seen = []
    for ele in array:
        if ele not in seen:
            seen.append(ele)
        else:
            continue
    return seen
    
array = [3,3,2,2,1,1,5,6,7]
print(duplicate(array))
            
